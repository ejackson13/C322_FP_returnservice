package edu.iu.c322.finalproject.returnservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReturnserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReturnserviceApplication.class, args);
	}

}
