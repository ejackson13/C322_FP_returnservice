package edu.iu.c322.finalproject.returnservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReturnserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
